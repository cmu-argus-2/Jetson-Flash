#!/bin/bash
set +e

export WORKSPACE=`pwd`
PUBLIC_SOURCE_URL="https://developer.nvidia.com/downloads/embedded/l4t/r36_release_v3.0/sources/public_sources.tbz2"
JETPACK_TAG="r36.3.0"
# JETPACK_TAG="uefi-202409.1"
# Make sure Docker does not require a sudo 

check_env_variables()
{
      if [ -z "$CROSS_COMPILE_AARCH64" ]; then
            echo "Cross_compile_aarch64 is empty. Please set it first"
            exit 1
      fi

      if [ -z "$CROSS_COMPILE_AARCH64_PATH" ]; then
            echo "Cross_compile_aarch64_path is empty. Please set it first"
            exit 1
      fi

}

get_codes()
{
      get_public_codes
      get_optee_codes
      get_atf_codes
      get_uefi_codes
}


get_public_codes()
{
      if [ ! -e "$WORKSPACE/downloads/public_source.tbz2" ]; then
            echo "Public source not found. Downloading"
            wget $PUBLIC_SOURCE_URL -O downloads/public_source.tbz2
      fi
      tar xpf downloads/public_source.tbz2 -C downloads/
}

get_optee_codes()
{     
      tar xpf downloads/Linux_for_Tegra/source/nvidia-jetson-optee-source.tbz2 -C $WORKSPACE/optee/
}

get_atf_codes()
{
      tar xpf downloads/Linux_for_Tegra/source/atf_src.tbz2 -C $WORKSPACE/atf
}

get_uefi_codes()
{
      cd $WORKSPACE/uefi
      source uefiSetup.sh
      edk2_docker init_edkrepo_conf
      edk2_docker edkrepo manifest-repos add nvidia https://github.com/NVIDIA/edk2-edkrepo-manifest.git main nvidia
      # Clone
      edk2_docker edkrepo clone $EDK2_BUILD_ROOT NVIDIA-Platforms $JETPACK_TAG
      sudo chown -hR $USER ./*
      apply_assert_patch
      apply_edk2_patch
      cd $WORKSPACE
}

apply_assert_patch()
{
      cd $EDK2_BUILD_ROOT/edk2-nvidia
      git apply $WORKSPACE/uefi/e96433c.diff
      cd $WORKSPACE/uefi
}

apply_edk2_patch()
{
      cd $EDK2_BUILD_ROOT/edk2
      git apply $WORKSPACE/uefi/0001-pip-requirements.txt-Hold-setuptools-to-80.9.patch
      cd $WORKSPACE/uefi
}

build_codes()
{
      build_uefi_codes
      build_optee_codes
      build_atf_codes
}

build_uefi_codes()
{
      cd $EDK2_BUILD_ROOT
      # Build optee image
      edk2_docker $EDK2_BUILD_ROOT/edk2-nvidia/Platform/NVIDIA/StandaloneMmOptee/build.sh
      # Build UEFI Image
      edk2_docker $EDK2_BUILD_ROOT/edk2-nvidia/Platform/NVIDIA/Jetson/build.sh
      export UEFI_STMM_PATH=$EDK2_BUILD_ROOT/images/uefi_StandaloneMmOptee_RELEASE.bin
      cp $UEFI_STMM_PATH $WORKSPACE
      cp $EDK2_BUILD_ROOT/images/uefi_Jetson_RELEASE.bin $WORKSPACE
}

build_optee_codes()
{
      cd $WORKSPACE/optee/
      ./optee_src_build.sh -p t234
      export TEE_RAW=$WORKSPACE/optee/optee/build/t234/core/tee-raw.bin

      dtc -I dts -O dtb -o ./optee/tegra234-optee.dtb ./optee/tegra234-optee.dts
      export TEE_DTB=$WORKSPACE/optee/optee/tegra234-optee.dtb
}

build_atf_codes()
{
      cd $WORKSPACE/atf/
      export NV_TARGET_BOARD=t234 # Not sure why needed. But it can't be empty
      ./nvbuild.sh
      export ATF_IMG=$WORKSPACE/atf/arm-trusted-firmware/t234-t234/tegra/t234/release/bl31.bin
}

build_optee_images()
{
      cd $WORKSPACE
      ./gen_tos_part_img.py \
         --monitor $ATF_IMG \
         --os $TEE_RAW \
         --dtb $TEE_DTB \
         --tostype optee \
         ./patched-tos.img
}

echo "Build patched OPTEE for Jetpack 6.0 (r36.3.0)"
check_env_variables
get_codes
build_codes
build_optee_images

